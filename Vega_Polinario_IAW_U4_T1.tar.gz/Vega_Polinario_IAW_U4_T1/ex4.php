<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

    echo "<h3>Ejercicio 4: If Statement</h3><br>";

    $abc = 1;

    while ($abc < 10) {

      echo "abc ";
      $abc++;

    };

    echo "<br><br>";

    $xyz = 1;

    do {

      echo "xyz ";
      $xyz++;

    } while ($xyz < 10);

    echo "<br><br>";

    $numeros = 1;

   for ($i=0;$i<9;$i++) {

     echo $numeros." ";
     $numeros++;

   };

   echo "<br>";

   $letra = 65;

   echo "<ol>";
   for ($i=0;$i<6;$i++) {

     echo "<li>Artículo ".chr($letra)."</li>";
     $letra++;

   };
   echo "</ol>";


    ?>
  </body>
</html>
