<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

    echo "<h3>Ejercicio 3: If Statement</h3><br>";

    $mes = Date(F);

    if ($mes == "August") {

      echo "Es agosto, así que hace mucho calor.";

    }else{

      echo "No agosto, al menos no en el pico del calor.";

    };

    ?>
  </body>
</html>
