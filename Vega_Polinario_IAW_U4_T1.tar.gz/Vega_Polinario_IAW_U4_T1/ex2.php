<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

    echo "<h3>Ejercicio 2: Contenido variable</h3><br>";

    $Harry = "Harry";
    $Num = 28;
    $Null = NULL;

    var_dump($Harry);
    echo "<br>";

    echo $Harry."<br>";

    var_dump($Num);
    echo "<br>";

    var_dump($Null);
    echo "<br>";

    ?>
  </body>
</html>
