<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

    echo "<h3>Ejercicio 1: Operadores aritmeticos y variables</h3><br>";

    $valor = 8;

    echo "El valor ahora es $valor.<br>";

    $valor = $valor+2;
    echo "Suma 2. El valor ahora es $valor.<br>";

    $valor = $valor-4;
    echo "Reste 4. El valor ahora es $valor.<br>";

    $valor = $valor*5;
    echo "Multiplique por 5. El valor ahora es $valor.<br>";

    $valor = $valor/3;
    echo "Divida por 3. El valor ahora es $valor.<br>";

    $valor = $valor+1;
    echo "Incremente el valor en uno. El valor ahora es $valor.<br>";

    $valor = $valor-1;
    echo "Decrementa el valor en uno. El valor ahora es $valor.";
    
    ?>
  </body>
</html>
