<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

    echo "<h3>Ejercicio 5: Loops II</h3><br>";

    $numero = 0;

    echo "<table>";

    for ($i=0;$i<10;$i++) {

      echo "<tr>";
      for ($e=0;$e<10;$e++) {

        if ($numero%2==0){

          echo "<td style='width:50px; height:50px; background-color:gray; border:1px solid black'></td>";

        } else{

          echo "<td style='width:50px; height:50px; background-color:red; border:1px solid black'></td>";

        };

        $numero++;

      };

      $numero++;
      echo "</tr>";
    };

    echo "</table>";

    ?>
  </body>
</html>
